/*default variables*/
#define LW232_CAN_BUS_SHIELD_CS_PIN   10
#define LW232_DEFAULT_BAUD_RATE        115200
